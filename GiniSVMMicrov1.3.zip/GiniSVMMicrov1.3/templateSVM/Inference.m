%-------------------------------------------------------------------------
% Test script to show how to run GiniMicroSVM
%-------------------------------------------------------------------------
% Uses the following data for training and evaluation
% testx -> test-validation data (number of data x Dimension)
% Ytest -> test-validation label (number of data x Dimension)
% The training and test-validation labels should be prior probabilities.
% An example for a three class label is [0 0 1] to indicate
% that the training label belongs to class 3. Or it could
% be [0.1 0.3 0.6] to indicate prior confidence.
%
% 
%-------------------------------------------------------------------------
% Copyright (C) Shantanu Chakrabartty 2002,2012,2013,2014,2015,2020
% Version: v1.3 
%-------------------------------------------------------------------------
% Licensing Terms: This program is granted free of charge for research and 
% education purposes. However you must obtain a license from the author to 
% use it for commercial purposes. The software must not be modified and 
% distributed without including the licensing terms. By using this 
% software you agree to the licensing terms:
%
% NO WARRANTY: BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO 
% WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW. 
% EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR 
% OTHER PARTIES PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, 
% EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
% WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE 
% ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.
% SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY 
% SERVICING, REPAIR OR CORRECTION. IN NO EVENT UNLESS REQUIRED BY 
% APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY COPYRIGHT HOLDER, OR ANY 
% OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE PROGRAM, BE LIABLE TO 
% YOU FOR DAMAGES, INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR 
% CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE 
% PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING 
% RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A 
% FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH 
% HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
% DAMAGES. 
%-------------------------------------------------------------------------

%-------------------------------------------------------------------------
% Load the Trained Parameters
%-------------------------------------------------------------------------
load ../data/TrainingParamLight;
%-------------------------------------------------------------------------
% Load the test data
%-------------------------------------------------------------------------
load ../data/TestData;

% Determine the size of the test data
[Ntest,D] = size(testx);
[Nytest,M] = size(Ytest);
if Nytest ~= Ntest,
   error('test Data size neq labels');
end;


for i = 1:Ntest,
   [val,ytestindex(i)] = max(Ytest(i,:) + 1e-6*rand(1,M));
end;



%------------------------------------------------------------------
% Below is the script to evaluate the performance on test set
%------------------------------------------------------------------
fprintf('Evaluating Performance on test set\n');
errordist = zeros(1,M);
error = 0;
etotaltest = zeros(1,M);
confusiontest = zeros(M,M);

[result] = GiniSVMDecision(testx,sv,W,bias,GAMMA,KSCALE,KTYPE);
for k = 1:Ntest,
   [maxval,ind] = max(result(k,:));
   etotaltest(ytestindex(k)) = etotaltest(ytestindex(k)) + 1;
   confusiontest(ind,ytestindex(k)) = confusiontest(ind,ytestindex(k)) + 1;
   if ind ~= ytestindex(k),
      error = error + 1;
      errordist(ytestindex(k)) = errordist(ytestindex(k)) + 1;
   end;
end;
fprintf('Multi-class test-validation Error = %d percent \n',ceil((error/Ntest)*100));
for i = 1:M,
   fprintf('Class %d: Total Data = %d; Error = %d percent \n',i,etotaltest(i),floor((errordist(i)/(etotaltest(i)+1e-9))*100));
end;
testresult = result;
clear result resultmargin;

% Now print the confusion matrix after normalization
confusiontest = confusiontest./(ones(M,1)*(etotaltest+1e-9))*100;
fprintf('test-validation Confusion Matrix\n');
floor(confusiontest)

%---------------------------------------
% Save the test results
%---------------------------------------
save ../data/TestresultsLight testresult confusiontest;
clear all
