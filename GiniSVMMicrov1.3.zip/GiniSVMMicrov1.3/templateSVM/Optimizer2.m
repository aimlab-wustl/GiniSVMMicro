function [W,b] = Optimizer2(x, y, z, numofiter, B, kscale, ktype);
%-------------------------------------------------------------------------
% function [W, b] = Optimizer1(x, y, numofiter, B,kscale, ktype);
%
%      Potential function GiniSVM regression using MATLAB QP solver.
%
%      x: independent variable, (L,N) with L: number of points; N: dimension
%      y: dependent variable, (L,M) containing class labels vector
%      z: sample template vectors
%      numberofiter: Total number of iterations allowed.
%      numofiter : Total number of optimization steps.
%      inpB: Generalization Factor.
%
%      OUTPUT
%      W: weight vector (L,M)
%      b: bias vector (1,M)
%-------------------------------------------------------------------------
% Copyright (C) Shantanu Chakrabartty 2002,2012,2013,2014,2015,2021
% Version: GiniSVMMicrov1.x
%-------------------------------------------------------------------------
% Licensing Terms: This program is granted free of charge for research and 
% education purposes. However you must obtain a license from the author to 
% use it for commercial purposes. The software must not be modified and 
% distributed without including the licensing terms. By using this 
% software you agree to the licensing terms:
%
% NO WARRANTY: BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO 
% WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW. 
% EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR 
% OTHER PARTIES PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, 
% EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
% WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE 
% ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.
% SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY 
% SERVICING, REPAIR OR CORRECTION. IN NO EVENT UNLESS REQUIRED BY 
% APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY COPYRIGHT HOLDER, OR ANY 
% OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE PROGRAM, BE LIABLE TO 
% YOU FOR DAMAGES, INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR 
% CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE 
% PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING 
% RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A 
% FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH 
% HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
% DAMAGES. 
%-------------------------------------------------------------------------


fprintf('Error: Optimizer2 is still under development, please use Optimizer1 instead\n');
return


%-----------------------------------------------------------------------------------
% First compute the size of the training data
%-----------------------------------------------------------------------------------
[L,D] = size(x);
[Ly,M] = size(y);
[Lz,D] = size(z);
if Ly~=L
    fprintf('Error: x and y different number of data points (%g/%g)\n\n', L, Ly);
    return
end;
              

%-----------------------------------------------------------------------------------
% Precompute the potential functions
%-----------------------------------------------------------------------------------
 
Q = Potential(x,z,kscale,ktype);

%-----------------------------------------------------------------------------------
% Need to solve the following Quadratic programming problem
% 
% Cost = 0.5*W(:)'*W(:) + 0.5*sum(B*((P(:)).^2 ))
% Subject to contraints
% W - Q'*(y-P)= 0 or W + Q'P = Q'y
% sum(Y-P,1) = 0
% sum(P,2) = 1
% 0 \ge P \le 1
%-----------------------------------------------------------------------------------

% MAKE SURE THIS IS CORRECT - ORDERING OF THE VARIABLES
% Variables are arranged as [W_{dk} P_{ik}]
% Hessian matrix
H = blkdiag(eye(Lz*M),B*eye(L*M));

% bias in the QP
f = zeros(Lz*M+L*M,1);

% Construct the linear constraints
A = repmat(Q',M,M);

Dm = repmat({ones(1,L)}, 1, M);  
D = blkdiag(Dm{:});

size(Q)
size(A)
size(D)

Aeq = [[eye(Lz*M) A];[zeros(M,Lz*M) D]];
beq = [A;D]*y(:);

ub = [1000*ones(Lz*M,1);ones(L*M,1)];
lb = [-1000*ones(Lz*M,1);zeros(L*M,1)];

% H
% f
% Aeq
% beq
% lb
% ub
% pause;

% Use the MATLAB QP solver
[x,fval,exitflag,output,lambda] = quadprog(H,f,[],[],Aeq,beq,lb,ub);
finalout = reshape(x,[M,Lz+L]);
%finalout = finalout';
% size(x)
% size(finalout)
% pause;
W = finalout(1:M,1:Lz);
W = W';
b = lambda(Lz*M+1:end);
b = b';





