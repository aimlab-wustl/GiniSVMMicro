function k = Potential(x, y, kscale, ktype);
%-------------------------------------------------------------------------
% function k = Potential(x, y, ktype,kscale);
%
% Calculates a potential function based on the input vector x.
% One variant of the Potential function calculates the similarity of x
% with the templates y in some metric space. kscale is the parameter in 
% the space.
%
% Another variant of the potential function implements a filter on the
% input x with y storing the filter parameters
%
% Copyright (C) Shantanu Chakrabartty 2002,2012,2013,2014,2015,2020, 2021
% Version: GiniSVMMicrov1.3
%-------------------------------------------------------------------------
% Licensing Terms: This program is granted free of charge for research and 
% education purposes. However you must obtain a license from the author to 
% use it for commercial purposes. The software must not be modified and 
% distributed without including the licensing terms. By using this 
% software you agree to the licensing terms:
%
% NO WARRANTY: BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO 
% WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW. 
% EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR 
% OTHER PARTIES PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, 
% EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
% WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE 
% ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.
% SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY 
% SERVICING, REPAIR OR CORRECTION. IN NO EVENT UNLESS REQUIRED BY 
% APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY COPYRIGHT HOLDER, OR ANY 
% OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE PROGRAM, BE LIABLE TO 
% YOU FOR DAMAGES, INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR 
% CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE 
% PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING 
% RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A 
% FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH 
% HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
% DAMAGES. 
%-------------------------------------------------------------------------

[Lx,N] = size(x);
[Ly,N] = size(y);
k = x*y';
 
 if ktype == 1				% Cauchy Potential function
    k = 2*k;
    k = k-sum(x.^2,2)*ones(1,Ly);
    k = k-ones(Lx,1)*sum(y.^2,2)';
    k = 1./(1+1/kscale*(-k+1e-6));
 elseif ktype == 2			% Gaussian Potential function
    k = 2*k;
    k = k-sum(x.^2,2)*ones(1,Ly);
    k = k-ones(Lx,1)*sum(y.^2,2)';
    k = exp(k/kscale);
  elseif ktype == 3			% User defined 
    % Define a custom potential function that satisfies your criterion
    % hardware friendly potential functions like below which uses only
    % threshold and a rectifier.
    k = max(0,(k/kscale - 0.5)); 
    
    % Functions that can not be described in closed form like using
    % ordinary differential equations (ODEs). In this case ignore the input 
    % template array and implement Ly ODEs, each of them acting on the
    % input vector array x.
    % An example of such a potential function could be
    % k = BandpassFilter(x,[FilterParameter Array])
  
end
 

